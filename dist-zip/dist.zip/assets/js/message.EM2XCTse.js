var r=(g=>(g[g.ImgUploadingMsg=0]="ImgUploadingMsg",g))(r||{});export{r as M};
